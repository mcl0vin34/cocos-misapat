System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/spine-17c81aa0.wasm")}}}));
